const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    fullName: String,
    userName: { type: String, unique: true, required: true },
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    dob: Date,
    phone: String,
    authPin: String,
    lastLogin: { type: Date },
});

module.exports = mongoose.model('User', UserSchema);